package configFile;

public class config_File 
{
	 public final static String reportPath=System.getProperty("user.dir")+"\\src\\reports\\";
	 public final static String screenShotPath=System.getProperty("user.dir")+"\\src\\reports\\screenshots\\";
	 public final static String testdata=System.getProperty("user.dir")+"\\src\\testData\\TestData.xls";
	 public final static String or=System.getProperty("user.dir")+"\\src\\objectRepository\\OR.properties";
	 
	 public final static String driverpath=System.getProperty("user.dir")+"\\Drivers\\";
	 
	 //update this variable
	 public final static String operabinary="C:\\Users\\AB46772\\AppData\\Local\\Programs\\Opera\\launcher.exe";
	 
	 public final static String url="http://www.newtours.demoaut.com/";
	 public final static long implicitwait=2;
	 public final static long explicitwait=3;
}
