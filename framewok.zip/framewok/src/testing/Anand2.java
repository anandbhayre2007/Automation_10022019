package testing;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class Anand2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		/*String str="My name is %s";
		
		String str2=String.format(str, "anand");
		System.out.println(str2);
		
		File htmlFile = new File("D:\\02092018\\Framework\\src\\reports\\AutomationReport_20181227_143720.html");
		Desktop.getDesktop().browse(htmlFile.toURI());
		*/
		
		String str="z";
		System.out.println(str.compareTo("Z"));
		
	}

}
